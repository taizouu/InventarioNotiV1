from django.contrib.auth.models import AbstractUser
from django.db import models

class Usuario(AbstractUser):
    es_vendedor = models.BooleanField(default=False, help_text="Designa si el usuario es un vendedor")
    es_administrador = models.BooleanField(default=False, help_text="Designa si el usuario es un administrador")

    def __str__(self):
        return self.username