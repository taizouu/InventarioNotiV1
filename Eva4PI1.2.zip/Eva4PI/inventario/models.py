from django.db import models
from django.utils.timezone import now

class Producto(models.Model):
    nombre = models.CharField(max_length=255)
    descripcion = models.TextField(blank=True, null=True)
    cantidad = models.IntegerField()
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.PositiveIntegerField(default=0)  # Campo necesario
    umbral_notificacion = models.PositiveIntegerField(default=5)  # Nuevo campo
    umbral_critico = models.IntegerField(
        help_text="Cantidad mínima antes de activar alerta de stock bajo"
    )
    creado_en = models.DateTimeField(auto_now_add=True)
    actualizado_en = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.nombre

class Notificacion(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    mensaje = models.TextField()
    creado_en = models.DateTimeField(default=now)
    leido = models.BooleanField(default=False)

    def __str__(self):
        return f"Notificación para {self.producto.nombre}"