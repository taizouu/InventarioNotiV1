from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Producto, Notificacion
from .forms import ProductoForm
from django.db import models
import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from django.conf import settings

def home(request):
    return render(request, 'home.html')

def listar_productos(request):
    productos = Producto.objects.all()
    return render(request, 'lista_productos.html', {'productos': productos})

def crear_producto(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_productos')
    else:
        form = ProductoForm()
    return render(request, 'form_producto.html', {'form': form})

# Editar un producto
def editar_producto(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        form = ProductoForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            return redirect('listar_productos')
    else:
        form = ProductoForm(instance=producto)
    return render(request, 'form_producto.html', {'form': form})

# Eliminar un producto
def eliminar_producto(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        producto.delete()
        return redirect('listar_productos')
    return render(request, 'confirmar_eliminar.html', {'producto': producto})

@login_required
def dashboard(request):
    productos_stock_bajo = Producto.objects.filter(cantidad__lte=models.F('umbral_critico'))
    total_productos = Producto.objects.count()
    total_stock = Producto.objects.aggregate(total=models.Sum('cantidad'))['total']
    notificaciones = Notificacion.objects.filter(leido=False)

    context = {
        'productos_stock_bajo': productos_stock_bajo,
        'total_productos': total_productos,
        'total_stock': total_stock,
        'notificaciones': notificaciones,
    }
    return render(request, 'dashboard.html', context)

@login_required
def marcar_notificacion_leida(request, pk):
    notificacion = get_object_or_404(Notificacion, pk=pk)
    notificacion.leido = True
    notificacion.save()
    return redirect('dashboard')

def send_email(subject, recipient, message):
    email = Mail(
        from_email=settings.DEFAULT_FROM_EMAIL,
        to_emails=recipient,
        subject=subject,
        html_content=message,
    )
    try:
        sg = SendGridAPIClient(os.getenv('SENDGRID_API_KEY'))
        response = sg.send(email)
        return response.status_code
    except Exception as e:
        print(f"Error sending email: {e}")