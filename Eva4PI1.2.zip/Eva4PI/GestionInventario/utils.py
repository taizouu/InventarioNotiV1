import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

def send_email(subject, recipient, message):
    """
    Envía un correo electrónico utilizando SendGrid.
    """
    email = Mail(
        from_email=os.getenv('DEFAULT_FROM_EMAIL'),
        to_emails=recipient,
        subject=subject,
        html_content=message,
    )
    try:
        sg = SendGridAPIClient(os.getenv('SENDGRID_API_KEY'))
        response = sg.send(email)
        print(f"Correo enviado a {recipient} con estado {response.status_code}")
    except Exception as e:
        print(f"Error enviando correo: {str(e)}")
