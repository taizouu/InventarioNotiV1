from django.contrib import admin
from django.urls import path, include
from usuarios import views
from django.shortcuts import redirect

urlpatterns = [
    path('admin/', admin.site.urls),
    path('registro/', views.registro, name='registro'),
    path('login/', views.iniciar_sesion, name='login'),
    path('logout/', views.cerrar_sesion, name='logout'),
    path('inventario/', include('inventario.urls')),
    path('', lambda request: redirect('home', permanent=False)),  # Redirige la raíz al Dashboard
]