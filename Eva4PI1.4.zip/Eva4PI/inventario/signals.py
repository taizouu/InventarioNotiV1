from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import send_mail
from .models import Producto
from django.conf import settings

@receiver(post_save, sender=Producto)
def enviar_notificacion_stock(sender, instance, **kwargs):
    if instance.cantidad < instance.umbral_critico:  # Verifica que este campo exista
        asunto = f"Alerta de stock bajo: {instance.nombre}"
        mensaje = (
            f"El producto {instance.nombre} tiene un stock bajo.\n"
            f"Stock actual: {instance.cantidad} unidades.\n"
            f"Por favor, considera reabastecer este producto."
        )
        destinatarios = ["guido.sc15@gmail.com"]  # Cambia esto según tu configuración
        send_mail(
            asunto,
            mensaje,
            settings.DEFAULT_FROM_EMAIL,  # Usa el remitente configurado
            destinatarios,
        )