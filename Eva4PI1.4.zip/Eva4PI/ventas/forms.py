from django import forms
from .models import Venta

class VentaForm(forms.ModelForm):
    class Meta:
        model = Venta
        fields = ['producto', 'cantidad']

    def clean(self):
        cleaned_data = super().clean()
        producto = cleaned_data.get('producto')
        cantidad = cleaned_data.get('cantidad')

        if producto and cantidad:
            if cantidad > producto.cantidad:
                raise forms.ValidationError(f"La cantidad solicitada ({cantidad}) excede el stock disponible ({producto.cantidad}).")
        return cleaned_data
