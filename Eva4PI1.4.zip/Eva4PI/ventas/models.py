from django.db import models
from django.conf import settings  # Importa settings para acceder a AUTH_USER_MODEL
from inventario.models import Producto  # Asegura que estás trabajando con el modelo Producto del inventario

class Venta(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField()
    vendedor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)  # Cambia User por AUTH_USER_MODEL
    fecha = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        # Rebaja el stock del producto al guardar la venta
        if self.producto.cantidad >= self.cantidad:
            self.producto.cantidad -= self.cantidad
            self.producto.save()
            super().save(*args, **kwargs)
        else:
            raise ValueError("Stock insuficiente")
