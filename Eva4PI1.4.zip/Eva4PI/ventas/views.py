from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.shortcuts import render, redirect
from .models import Producto  # Asegúrate de tener este modelo definido
from .forms import VentaForm

@login_required
def registrar_venta(request):
    if request.method == 'POST':
        form = VentaForm(request.POST)
        if form.is_valid():
            venta = form.save(commit=False)
            venta.vendedor = request.user  # Asigna el usuario autenticado como vendedor
            try:
                venta.save()  # Esto también debería rebajar el stock
                messages.success(request, "Venta registrada con éxito.")
            except ValueError as e:
                messages.error(request, str(e))
            return redirect('ventas:registrar_venta')
    else:
        form = VentaForm()

    # Obtener los productos disponibles
    productos = Producto.objects.all()  # Ajusta este queryset según tus necesidades

    return render(request, 'registrar_venta.html', {'form': form, 'productos': productos})